<?php
session_start();

    $connect = mysqli_connect('localhost','root','','Crud_tareas');

    /*if(isset($connect)){
        echo "Conexion exitosa";
    }else{
        echo "ERROR";
    }*/

?>